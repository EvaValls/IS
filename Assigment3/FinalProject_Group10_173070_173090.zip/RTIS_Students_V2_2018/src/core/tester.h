#ifndef TESTER_H
#define TESTER_H

#include "matrix4x4.h"

class Tester
{
public:
    Tester();

    static void testMatrixClass();
};

#endif // TESTER_H
